Angular Google Maps (AGM) Snazzy Info Window - Angular Google Maps components
=========

@agm/snazzy-info-window is an extension for the @agm/core package that provides solutions for styleable/customizable info windows with the help of ['Snazzy Info Window'](https://github.com/atmist/snazzy-info-window).

The sources for this package are in the [angular-google-maps](https://github.com/SebastianM/angular-google-maps) repository. Please file issues and pull requests against that repo.

License: See LICENSE file in this folder.
