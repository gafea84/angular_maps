Angular Google Maps (AGM) Core - Angular 2+ Google Maps components
=========

@agm/core contains solutions for the Google Maps JavaScript Core API.

The sources for this package are in the [angular-google-maps](https://github.com/SebastianM/angular-google-maps) repository. Please file issues and pull requests against that repo.
