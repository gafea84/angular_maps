
export { AgmDrawingManager } from './directives/drawing-manager';
export { AgmDrawingManagerTrigger } from './directives/drawing-manager-trigger';
